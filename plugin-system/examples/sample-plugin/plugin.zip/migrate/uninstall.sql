-- 测试迁移插件的卸载脚本
-- 删除测试表

DROP TABLE IF EXISTS plugin_migration_test;